basis33 is a fixed-width bitmap font for programming and text editing, which contains Latin, Cyrillic, Greek and Hebrew characters. 

It�s designed by Manchson basing on Latin-only font Proggy Clean by Tristan Grimmer.
 
basis33 is free/libre software, you are welcome to redistribute and/or modify it under the terms of MIT/Expat license; see LICENSE for details.


